# Kimchi Premium Arbitrage Bot
__version__ = "1.0.0"